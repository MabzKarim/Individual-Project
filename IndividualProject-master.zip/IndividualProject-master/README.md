# COURSERECOMMENDER


- How to Run the Program

In order to run CourseRecommender, the following steps must be executed in the specified order:
1. Extract the ‘CourseRecommender.zip zip file.
2. Click ‘File’.
3. Click ‘Open...’ 
4. Locate the unzipped CourseRecommender folder.
5. Open the ‘CourseRecommender.py’ file
6. Click ‘Run Module’
7. A new python window should appear displaying that the system is running on localhost.
8. The system can now be accessed on the address: ‘http//localhost:8157’.

