from flask import Flask, render_template, session, request, redirect, g, url_for
import os
import sys
from models import *
from interest_model import *
import logging
import course_recommendation

app = Flask(__name__)
app.secret_key = os.urandom(24)

@app.before_request
def before_request():
    initialize_db()

@app.teardown_request
def teardown_request(exception):
    db.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/subjectspage/')
def subjectspage():
    return render_template('subjectspage.html',
                           subjects_available = Subject.select())

@app.route('/interestspage/')
def interestspage():
    return render_template('interestspage.html',
                           interests_available = Interest.select())

@app.route('/gradespage/')
def gradespage():
    return render_template('gradespage.html')

@app.route('/recommendation/')
def recommendation():
    subjects_chosen = session['subjects_selected']
    recommendations = course_recommendation.return_recommendations(subjects_chosen)
    descriptions = []
    for i in recommendations:
        descriptions.append(course_recommendation.look_up_desc(i))

    return render_template('recommendation.html', recommendations = recommendations, descriptions = descriptions)

@app.route('/courses/')
def courses():
    return render_template('courses.html')

@app.route('/modules/')
def modules():
    return render_template('modules.html')

@app.route('/subjects/')
def subjects():
    return render_template('subjects.html')

@app.route('/recommend_course/', methods=['POST'])
def recommend_course():
    if request.method == 'POST':
        if request.form['subjectselector'] != '':
            session['subjects_selected'] = request.form.getlist('subjectselector')
            return redirect(url_for('interestspage'))
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(port=8157, debug=True)
