import numpy as np 
import pandas as pd
import csv

# A simple way to compute Pearson Correlation
def pearsonR(s1, s2):
    s1_c = s1-s1.mean()
    s2_c= s2-s2.mean()

    coveriance_s1_s2 = np.sum(s1_c*s2_c)
    standard_dev_s1_s2 = np.sqrt(np.sum(s1_c**2)* np.sum(s2_c**2))
    coeffecient = coveriance_s1_s2 / standard_dev_s1_s2
    return coeffecient

# A function to make N recommendations based on Pearson Correlation.
# The parameters here are: course name, matrix name and number of recommendations.
def recommend(course, M, n):
    reviews=[]
    for title in M.columns:
        if title == course:
            continue
        cor= pearsonR(M[course], M[title])
        if np.isnan(cor):
            continue
        else:
            reviews.append((title, cor))
            
    reviews.sort(key= lambda tup: tup[1], reverse=True)
    return reviews[:n]


def return_recommendations(subject_chosen):
    meta= pd.read_csv("courses_metadata.csv",  encoding = 'latin-1')
    meta= meta[['id', 'original_title', 'original_language']]
    meta = meta[meta['original_language']== 'en'] #just want courses in English
    meta.head()

    #importing course ratings
    ratings= pd.read_csv("courses_ratings.csv", encoding = 'latin-1')
    ratings= ratings[['userId', 'id', 'rating']]
    # taking a 1MM sample because it can take too long to pivot data later on
    ratings=ratings.head(1000000)

    #convert data types before merging
    meta.id =pd.to_numeric(meta.id, errors='coerce')
    ratings.id = pd.to_numeric(ratings.id, errors= 'coerce')

    #create a single dataset merging the previous 2
    data= pd.merge(ratings, meta, on='id', how='inner')
    data.head()

    #course matrix so that I can use the recommender function later
    matrix= data.pivot_table(index='userId', columns='original_title', values='rating')
    matrix.head()
    subjects_recommended = set()
    for i in subject_chosen:
        temp_recommend = recommend(i, matrix, 6) #top 5 recommendations of courses
        count = 0
        for i in temp_recommend:
            subjects_recommended.add(temp_recommend[count][0])
            count += 1
    subjects_recommended = list(subjects_recommended)
    subjects_recommended = subjects_recommended[0:6]
    return subjects_recommended


def look_up_desc(subj_name):
    with open("courses_metadata.csv", encoding = 'latin-1') as csvfile:
        readCSV = csv.reader(csvfile, delimiter = ',')
        for row in readCSV:
            if row[2].lower() == subj_name.lower():
                return row[3]
