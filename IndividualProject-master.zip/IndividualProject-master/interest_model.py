from peewee import *

db = SqliteDatabase('interests.db')

class Interest(Model):
    id = PrimaryKeyField()
    interest_name = TextField()

    class Meta:
        database = db

def initialize_db():
    db.connect()
    db.create_tables([Interest], safe=True)
