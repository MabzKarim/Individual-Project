from peewee import *

db = SqliteDatabase('subjects.db')

class Subject(Model):
    id = PrimaryKeyField()
    subject_name = TextField()

    class Meta:
        database = db

def initialize_db():
    db.connect()
    db.create_tables([Subject], safe=True)
